PULLBACK TRADING — GITHUB UPLOAD

Upload these files to the root of your GitHub repository:
- index.html
- claim-50-off.html

The .txt copies contain the same source code for easy viewing.

After deployment:
1. Open the homepage and click every Premium/50% CTA.
2. Submit one test lead on claim-50-off.html.
3. Confirm the lead appears in Supabase > Table Editor > discount_leads.
4. Confirm FIRST50 exists in Whop as 50% off the first month.

Do not publish a Supabase secret/service-role key. The included sb_publishable_ key is the browser-safe key protected by Row Level Security.
